<?php
	$cart = session()->has('cart') ? session('cart') : null;
?>

<div class="modal fade cart-modal mini-cart" id="cart-modal-ex" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <div class="modal-dialog " role="document">
        <!--Content-->

        <div class="modal-content mini-cart">
            <!--Header-->
            <div class="modal-header ">

                <h4 class="modal-title font-weight-bold dark-grey-text" id="myModalLabel">Your cart</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <!--Body-->
            <?php if($cart == null): ?>
                <p style="margin-left: 20%;margin-top: 5px">Chưa có sản phẩm nào trong giỏ</p>
            <?php else: ?>
            <div class="modal-body">

                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cart->getListCartItem(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><img src="<?php echo e(asset('images/product/'.$cartItem->getProduct()->images[0]->name)); ?>" style="width: 100px"></th>
                            <td><a href="<?php echo e(url('/product/detail/'.$cartItem->getProduct()->id)); ?>"><?php echo e($cartItem->getProduct()->name); ?></a></td>
                            <td><?php echo e(number_format(($cartItem->getProduct()->promotion_price!=0)?$cartItem->getProduct()->promotion_price:$cartItem->getProduct()->price)); ?>đ</td>
                            <td><input type="number"  onclick="reload()" class="quantity<?php echo e($cartItem->getProduct()->id); ?>" onkeyup="quantityCart(<?php echo e($cartItem->getProduct()->id); ?>)" max="<?php echo e($cartItem->getProduct()->quantity_in_stock); ?>" min="0" value="<?php echo e($cartItem->getQuantity()); ?>" onchange="updateCartItem(<?php echo e($cartItem->getProduct()->id); ?>)" style="width: 50px"></td>
                            
                            <td>
                                <a href="javascript: deleteCartItem(<?php echo e($cartItem->getProduct()->id); ?>);">
                                    <i class="fas fa-eraser"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot >
                        <tr class="total-selected " >
                            <th>Tổng tiền :</th>
                            <th><?php echo e(number_format($cart->getGrandTotal())); ?>đ</th>
                        </tr>
                    </tfoot>

                    <input type="hidden" class="total-quantity-hidden" value="<?php echo e($cart->getTotalQuantity()); ?>">

                </table>



            </div>

            <!--Footer-->
            <div class="modal-footer">
                <?php endif; ?>
                <a href="<?php echo e(url('/cart')); ?>"><button class="btn btn-success btn-rounded btn-sm">Views</button></a>
                <?php if($cart!=null): ?>
                <a   href="javascript: updateCartItem(<?php echo e($cartItem->getProduct()->id); ?>)"><button class="btn btn-warning btn-rounded btn-sm">Update</button></a>
                <a href="<?php echo e(url('/order')); ?>"><button class="btn btn-primary btn-rounded btn-sm">Checkout</button></a>
                <?php endif; ?>
                
            </div>
        </div>
        <!--/.Content-->
    </div>
</div>
<?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/cart/minicart.blade.php ENDPATH**/ ?>