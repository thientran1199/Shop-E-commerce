
<?php $__env->startSection('title'); ?>
	<title>Lịch sử đặt hàng</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<!-- menu -->
		<?php echo $__env->make('frontend.customer.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- end menu -->
		<div class="col-md-9">
			<div class="page-header">
			    <h3>Lịch sử đặt hàng</h3>
			    <hr>
			</div>
			<div class="card-body border bg-white rounded" style="overflow-y: scroll;height: 400px">
				<table class="table table-hover table-responsive-md">
					<thead>
						<tr>
							<th style="width: 30px">Id</th>
							<th>Thời gian đặt hàng</th>
							<th>Thanh toán</th>
							<th>Tổng tiền</th>
							<th>Ghi chú</th>
							<th>Trạng thái</th>
							<th>Chi tiết</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $listOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->id); ?></td>
							<td><?php echo e($item->created_at); ?></td>
							<td><?php echo e($item->payment->method); ?></td>
							<td><?php echo e(number_format($item->grand_total)); ?>đ</td>
							<td><?php echo e(($item->note!='')?$item->note:'(trống)'); ?></td>
							<?php switch($item->status):
							case ('Chờ xử lý'): ?>
								<td><span class="btn btn-sm btn-info"><?php echo e($item->status); ?></span></td>
								<?php break; ?>
							<?php case ('Hủy'): ?>
								<td><span class="btn btn-sm btn-danger"><?php echo e($item->status); ?></span></td>
								<?php break; ?>
							<?php case ('Đang giao'): ?>
								<td><span class="btn btn-sm btn-warning"><?php echo e($item->status); ?></span></td>
								<?php break; ?>
							<?php case ('Đã nhận hàng'): ?>
								<td><span class="btn btn-sm btn-success"><?php echo e($item->status); ?></span></td>
								<?php break; ?>
							<?php default: ?>
							<?php endswitch; ?>	
							<td class="text-center"><a href="<?php echo e(url('/customer/order-history/detail/'.$item->id)); ?>"><i class="fas fa-eye"></i></a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
			
				</table>
			</div>	
		</div>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/customer/order_history/list.blade.php ENDPATH**/ ?>