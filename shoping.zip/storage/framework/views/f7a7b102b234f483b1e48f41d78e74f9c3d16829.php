
<?php $__env->startSection('title'); ?>
	<title>Địa chỉ giao hàng</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<!-- menu -->
		<?php echo $__env->make('frontend.customer.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- end menu -->
		<div class="col-md-9">
			<div class="page-header">
			    <h3>Địa chỉ giao hàng<small style="float: right;"><a href="<?php echo e(url('/customer/shipping-address/add')); ?>" class="btn btn-dark btn-sm">+ Thêm địa chỉ</a> </small> </h3>
			    <hr>
			</div>
			<div class="card-body border rounded bg-white" style="height: 400px;overflow-y: scroll;">
				<?php if(count($listCustomerShippingAddress)==0): ?>
					<i>Chưa có địa chỉ nào, mời bạn bổ sung</i>
				<?php endif; ?>
				<?php $__currentLoopData = $listCustomerShippingAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="row border rounded mb-3 bg-light">
					<div class="col-md-7">
						<div class="row">
							<div class="col-md-4 text-muted">Họ và tên</div>
							<div class="col"><?php echo e($item->recipient_name); ?></div>
							<?php if($item->default == 1): ?>
							<div class="col"><span class="badge badge-info">Mặc định</span></div>
							<?php endif; ?>
						</div>
						<div class="row">
							<div class="col-md-4 text-muted">Điện thoại</div>
							<div class="col"><?php echo e($item->recipient_phone); ?></div>
						</div>
						<div class="row">
							<div class="col-md-4 text-muted">Địa chỉ</div>
							<div class="col">
								<div><?php echo e($item->province); ?></div>
								<div><?php echo e($item->district); ?></div>
								<div><?php echo e($item->wards); ?></div>
								<div><?php echo e($item->address_detail); ?></div>
							</div>
						</div>
					</div>
					<div class="col pt-2 text-center">
						<a href="<?php echo e(url('/customer/shipping-address/edit/'.$item->id)); ?>" class="btn btn-info btn-sm">Sửa</a>
						<span data-toggle="modal" data-target="#deleteAddress<?php echo e($item->id); ?>" class="btn btn-danger btn-sm text-white">Xóa</span>
					</div>
				</div>
				<!-- modal delete -->
				<div class="modal fade" id="deleteAddress<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($item->id); ?>"
			        aria-hidden="true">
			        <div class="modal-dialog" role="document">
			            <div class="modal-content">
			                <div class="modal-header">
			                    <h5 class="modal-title" id="exampleModalLabel<?php echo e($item->id); ?>">Bạn muốn xóa địa chỉ giao hàng này?</h5>
			                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
			                        <span aria-hidden="true">×</span>
			                    </button>
			                </div>
			                <div class="modal-body">Chọn "Đồng ý" bên dưới để xóa địa chỉ.</div>
			                <div class="modal-footer">
			                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Thoát</button>
			                    <a class="btn btn-primary" href="<?php echo e(url('/customer/shipping-address/delete/'.$item->id)); ?>">Đồng ý</a>
			                </div>
			            </div>
			        </div>
			    </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>  			
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/customer/shipping_address/list.blade.php ENDPATH**/ ?>