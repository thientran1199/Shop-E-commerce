<?php $__env->startSection('title'); ?>
    <title>Product</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $cart = session()->has('cart') ? session('cart') : null;
?>
<div class="row">
    <!-- danh muc -->
        
    <!-- end danh muc -->
    <div class="col">
        <div class="page-header">
                <h3>Sản phẩm
                    <?php
                        $key= request()->get('key');
                        $id = request()->get('category');
                        if($id!=null) {
                        $db = DB::table('category')->where('id',$id)->first();
                    ?>
                           <small>> <?php echo e($db->name); ?></small>
                    <?php }?>
                        <small> <?php echo e((isset($key))?'> Tìm kiếm':''); ?></small>
                </h3>
                <hr>
        </div>
        <div class="container">
            <!-- lựa chọn nâng cao như giá, sắp tên -->
            <?php echo $__env->make('frontend.advanced_options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <hr>
        <div class="mb-4">
            <p>Hiển thị <?php echo e($listProduct->count()); ?> sản phẩm (tổng số <?php echo e($listProduct->total()); ?> sản phẩm) <?php echo e((isset($key))?('cho từ khóa : "'.$key.'"'):''); ?></p>

        </div>
        <div class="row">
            <?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4">
                <!--Card-->
                <div class="card card-ecommerce">

                    <!--Card image-->
                    <div class="view overlay">
                        <img src="<?php echo e(asset('images/product/'.$item->images[0]->name)); ?>"  class="img-fluid" alt="ảnh<?php echo e($item->name); ?>">
                        <a href="<?php echo e(url('/product/detail/'.$item->id)); ?>">
                            <div class="mask rgba-white-slight"></div>
                        </a>
                    </div>
                    <!--Card image-->

                    <!--Card content-->
                    <div class="card-body">
                        <!--Category & Title-->
                    <?php
                        $productsSell = DB::table('product')->join('order_item','product.id','=','order_item.product_id')->join('order','order.id','=','order_item.order_id')->where('order.status','Đã nhận hàng')->get();
                        $listLatest = DB::table('product')->orderBy('created_at','desc')->where('enabled',1)->limit(12)->get();
                    ?>
                        <h5 class="card-title mb-1"><strong><a href="<?php echo e(url('/product/detail/'.$item->id)); ?>" class="dark-grey-text"><?php echo e($item->name); ?></a></strong></h5>
                        <?php if(isset($productsSell)  ): ?>
                        <span class="badge badge-danger mb-2">bestseller</span>
                        <?php endif; ?>
                        <?php if($item->promotion_price!=0): ?>
                        <span class="badge badge-success mb-2 ml-2">SALE</span>
                        <?php endif; ?>
                        <?php if($listLatest ==true): ?>
                        <span class="badge badge-info mb-2 ml-2">new</span>
                        <?php endif; ?>
                        <!-- Rating -->
                        <ul class="rating">
                            <li><i class="fas fa-star blue-text"></i></li>
                            <li><i class="fas fa-star blue-text"></i></li>
                            <li><i class="fas fa-star blue-text"></i></li>
                            <li><i class="fas fa-star blue-text"></i></li>
                            <li><i class="fas fa-star grey-text"></i></li>
                        </ul>

                        <!--Card footer-->
                        <div class="card-footer pb-0">
                            <div class="row mb-0">
                                <h5 class="mb-0 pb-0 mt-1 font-weight-bold">
                                    <?php if($item->promotion_price!=0): ?>
                                    <span class="red-text">
                                        <strong><?php echo e($item->promotion_price); ?>VNĐ</strong>
                                    </span>

                                    <span class="grey-text"><small><s><?php echo e($item->price); ?> VNĐ</s></small></span>
                                    <?php else: ?>
                                    <span class="red-text">
                                        <strong><?php echo e($item->price); ?>VNĐ</strong>
                                    </span>
                                    <?php endif; ?>
                                </h5>

                                <span class="float-right">
                                <?php if($item->quantity_in_stock>0): ?>
                                    <?php if($cart!=null&&array_key_exists($item->id,$cart->getListCartItem())): ?>
                                    <a class="add-cart<?php echo e($item->id); ?>" href="javascript:void(0);" data-toggle="tooltip"   data-placement="top" title="Đã thêm vào giỏ" ><i class="fas fa-check ml-3"></i></a>
                                    <?php else: ?>
                                    <a class="add-cart<?php echo e($item->id); ?>" href="javascript: addCartItem(<?php echo e($item->id); ?>);" data-toggle="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-shopping-cart ml-3"></i></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                
                                    <a title="Out Stock" data-toggle="tooltip" data-placement="top" ><i class="far fa-frown"></i> </a>
                                <?php endif; ?>
                                </span>
                            </div>
                        </div>

                    </div>
                    <!--Card content-->

                </div>
                <!--Card-->

            </div>
            <!--Grid column-->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($listProduct->withQueryString()->links()); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/product.blade.php ENDPATH**/ ?>