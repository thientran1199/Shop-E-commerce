<?php
$rangePrice = request()->get('rangePrice');
$sort = request()->get('sort');
?>

<form action="" method="GET">
	<?php if($id!=null): ?>
	<input type="hidden" name="category" value="<?php echo e(request()->get('category')); ?>">
	<?php endif; ?>
	<?php if($key!=null): ?>
	<input type="hidden" name="key" value="<?php echo e(request()->get('key')); ?>">
	<?php endif; ?>
	<div class="row border rounded bg-white card-body advandce_options">
		<div class="col-10">
			<div class="row range-price">
				<div class="col-md-1">
				<b>Giá:</b>
				</div>
				<div class="col-md-11">
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="0" id="tatca" checked>
						<span>Tất cả</span>
					</label>
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="1" id="duoi5tr" <?php echo e(($rangePrice==1)?'checked':""); ?>>
						<span>Dưới 5 triệu</span>
					</label>
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="2" id="5den10tr" <?php echo e(($rangePrice==2)?'checked':""); ?>>
						<span>5 - 10 triệu</span>
					</label>
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="3" id="10den15tr" <?php echo e(($rangePrice==3)?'checked':""); ?>>
						<span for="10den15tr">10 - 15 triệu</span>
					</label>
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="4" id="15den20tr" <?php echo e(($rangePrice==4)?'checked':""); ?>>
						<span for="15den20tr">15 - 20 triệu</span>
					</label>
					<label class="border rounded">
						<input type="radio" name="rangePrice" value="5" id="tu20tr" <?php echo e(($rangePrice==5)?'checked':""); ?>>
						<span for="tu20tr">20 triệu trở lên</span>
					</label>
				</div>
			</div>
			<div class="row">
				<div >
				<b>Sắp xếp:</b>
                <select class="form-control">
                    <option>option 1</option>
                    <option>option 2</option>
                    <option>option 3</option>
                    <option>option 4</option>
                    <option>option 5</option>
                  </select>
				
				</div>
			</div>
		</div>
		<div class="col-2">
			<input type="submit" name="" value="Lọc" style="height: 100%;" class="btn btn-secondary">
		</div>
	</div>
</form>
<?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/advanced_options.blade.php ENDPATH**/ ?>