<?php $__env->startSection('title'); ?>
	<title>Home</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.danhmuc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
	$cart = session()->has('cart') ? session('cart') : null;
?>
<!-- Grid row -->
<div class="row ">

    <!-- Content -->
    <div class="col-lg-12">



        <!--Section: Products-->
        <section>

            <!--Grid row-->
            <div class="row">
                <!--Grid column-->
                <div class="col-12">

                    <!-- Grid row -->
                    <div class="row">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Grid column-->
                        <div class="col-lg-4 col-md-12 mb-4 " height="400px" >

                            <!--Card-->
                            <div class="card card-ecommerce" >

                                <!--Card image-->
                                <div class="view overlay">
                                    <img src="<?php echo e(asset('images/product/'.$item->images[0]->name)); ?>" class="img-fluid" alt=" ">
                                    <a href="<?php echo e(url('/product/detail/'.$item->id)); ?>">
                                        <div class="mask rgba-white-slight"></div>
                                    </a>
                                </div>
                                <!--Card image-->

                                <!--Card content-->
                                <div class="card-body">
                                    <!--Category & Title-->

                                    <h5 class="card-title mb-1"><strong><a href="<?php echo e(url('/product/detail/'.$item->id)); ?>" class="dark-grey-text"><?php echo e($item->name); ?></a></strong></h5>
                                  <?php if($item->promotion_price!=0): ?>
                                  <span class="badge badge-success mb-2 ml-2">SALE</span>
                                  <?php endif; ?>
                                  <?php if($listLatest ==true): ?>
                                  <span class="badge badge-info mb-2 ml-2">new</span>
                                  <?php endif; ?>
                                  
                                    <span class="badge badge-danger mb-2">bestseller</span>
                                    <!-- Rating -->
                                    <ul class="rating">
                                        <li><i class="fas fa-star blue-text"></i></li>
                                        <li><i class="fas fa-star blue-text"></i></li>
                                        <li><i class="fas fa-star blue-text"></i></li>
                                        <li><i class="fas fa-star blue-text"></i></li>
                                        <li><i class="fas fa-star blue-text"></i></li>
                                    </ul>

                                    <!--Card footer-->
                                    <div class="card-footer pb-0">
                                        <div class="row mb-0">
                                            <?php if($item->promotion_price!=0): ?>
                                            <span class="red-text">
                                                <strong><?php echo e($item->promotion_price); ?>VNĐ</strong>
                                            </span>

                                            <span class="grey-text"><small><s><?php echo e($item->price); ?> VNĐ</s></small></span>
                                            <span class="float-right">
                                                <a class="" data-toggle="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-shopping-cart ml-3"></i></a>
                                            </span>
                                            <?php else: ?>
                                            <span class="red-text">
                                                <strong><?php echo e($item->price); ?>VNĐ</strong>
                                            </span>
                                            <span class="float-right">
                                                <?php if($item->quantity_in_stock>0): ?>
                                                    <?php if($cart!=null&&array_key_exists($item->id,$cart->getListCartItem())): ?>
                                                    <a class="add-cart<?php echo e($item->id); ?>" href="javascript:void(0);" data-toggle="tooltip"   data-placement="top" title="Đã thêm vào giỏ" ><i class="fas fa-check ml-3"></i></a>
                                                    <?php else: ?>
                                                    <a class="add-cart<?php echo e($item->id); ?>" href="javascript: addCartItem(<?php echo e($item->id); ?>);"  onclick="reload()" data-toggle="tooltip" data-placement="top" title="Add to Cart"><i class="fas fa-shopping-cart ml-3"></i></a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="btn btn-warning"><i class="far fa-frown"></i> Sản phẩm đã bán hết</span>
                                                <?php endif; ?>
                                            </span>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>

                                </div>
                                <!--Card content-->

                            </div>
                            <!--Card-->

                        </div>
                        <!--Grid column-->


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <!--Grid row-->




                </div>
                <?php echo e($product->links()); ?>

            </div>
            <!--Grid row-->

        </section>
        <!--Section: Products-->

       

    </div>
    <!-- /.Content -->

</div>
<!-- Grid row -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/home.blade.php ENDPATH**/ ?>