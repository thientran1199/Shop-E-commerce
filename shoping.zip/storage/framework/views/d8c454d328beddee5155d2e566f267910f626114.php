
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Order</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Oder</li>
            <li class="breadcrumb-item active ">List</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="card shadow mb-4">
<div class="card-body">
    <div class="table-responsive">
    	<table class="table table-bordered table-sm" id="dataTable" cellspacing="0" width="100%">
    		<thead>
				<tr>
					<th>Id</th>
					<th>Thời gian đặt hàng</th>
					<th>Thanh toán</th>
					<th>Tổng tiền</th>
					<th>Ghi chú</th>
					<th>Trạng thái</th>
					<th>Chi tiết</th>
				</tr>
			</thead>
			
			<tbody>
				<?php $__currentLoopData = $listOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($item->id); ?></td>
					<td><?php echo e($item->created_at); ?></td>
					<td><?php echo e($item->payment->method); ?></td>
					<td><?php echo e(number_format($item->grand_total)); ?>đ</td>
					<td><?php echo e(($item->note!='')?$item->note:'(trống)'); ?></td>
					<?php switch($item->status):
					case ('Chờ xử lý'): ?>
						<td><span class="btn btn-sm btn-info"><?php echo e($item->status); ?></span></td>
						<?php break; ?>
					<?php case ('Hủy'): ?>
						<td><span class="btn btn-sm btn-danger"><?php echo e($item->status); ?></span></td>
						<?php break; ?>
					<?php case ('Đang giao'): ?>
						<td><span class="btn btn-sm btn-warning"><?php echo e($item->status); ?></span></td>
						<?php break; ?>
					<?php case ('Đã nhận hàng'): ?>
						<td><span class="btn btn-sm btn-success"><?php echo e($item->status); ?></span></td>
						<?php break; ?>
					<?php default: ?>
					<?php endswitch; ?>	
					<td class="text-center"><a href="<?php echo e(url('admin-page/order/detail/'.$item->id)); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-eye"></i></a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
    	</table>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>    	
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/order/list.blade.php ENDPATH**/ ?>