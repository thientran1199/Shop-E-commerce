
<?php $__env->startSection('content'); ?>
   <!-- Content Header (Page header) -->
   <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Category</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Category</li>
            <li class="breadcrumb-item active "><?php echo e((request()->is('admin-page/category/add'))?'Thêm':'Sửa'); ?></li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
<!-- Page Heading -->

<div class="card shadow mb-4">
<div class="card-body">
		<form action="" method="post">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-sm-3"><b>Tên danh mục</b></div>
				<div>
					<input type="text" name="stringName" value="<?php echo e(isset($category->name)?$category->name:''); ?>" placeholder="Nhập tên danh mục" class="form-control">
				</div>
			</div>
			<?php if($errors->has('stringName')): ?>
				<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('stringName')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			 	</button>
				</div>
			<?php endif; ?>
			<div class="row" style="margin-top:5px;">
				<div class="col-sm-3"></div>
				<div>
					<input type="submit" name="" value="Thực thi" class="btn btn-success">
				</div>
			</div>
		</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/category/add_edit.blade.php ENDPATH**/ ?>