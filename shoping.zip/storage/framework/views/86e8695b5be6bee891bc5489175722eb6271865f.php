<?php $__env->startSection('content'); ?>
       <!-- Content Header (Page header) -->
       <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Category</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
                <li class="breadcrumb-item active ">Category</li>
                <li class="breadcrumb-item active ">List</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
<!-- Page Heading -->

<div class="card shadow mb-4 col-md-9 col-lg-11 mx-auto">
<div class="card-body">
<div class="alert alert-info text-center mt-1 show" style="background-color: rgb(199, 185, 185); color: black;">Không thể xóa các danh mục còn sản phẩm</div>
<div class="table-responsive">
	<table class="table table-bordered" id="dataTable" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>ID</th>
				<th>Tên danh mục</th>
				<th>Sửa</th>
				<th>Xóa</th>
			</tr>
		</thead>
		
		<tbody>
			<?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($item->id); ?></td>
				<td><?php echo e($item->name); ?></td>
				<td class="text-center">
					<a href="<?php echo e(url('/admin-page/category/edit/'.$item->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
				</td>
				<td class="text-center">
					<span data-toggle="modal" data-target="#delete<?php echo e($item->id); ?>" class="btn btn-danger btn-sm <?php echo e((count($item->products)>0)?'disabled':''); ?>" ><i class="fas fa-trash-alt"></i></span>
				</td>
			</tr>
			<!-- modal delete -->
				<div class="modal fade" id="delete<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($item->id); ?>"
			        aria-hidden="true">
			        <div class="modal-dialog" role="document">
			            <div class="modal-content">
			                <div class="modal-header">
			                    <h5 class="modal-title" id="exampleModalLabel<?php echo e($item->id); ?>">Bạn muốn xóa bản ghi này?</h5>
			                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
			                        <span aria-hidden="true">×</span>
			                    </button>
			                </div>
			                <div class="modal-body">Chọn "Đồng ý" bên dưới để xóa.</div>
			                <div class="modal-footer">
			                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Thoát</button>
			                    <a class="btn btn-primary" href="<?php echo e(url('/admin-page/category/delete/'.$item->id)); ?>">Đồng ý</a>
			                </div>
			            </div>
			        </div>
			    </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/category/list.blade.php ENDPATH**/ ?>