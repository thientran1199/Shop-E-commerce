<div class="col-md-3 pb-4">
	<div class="card-header" style="cursor: pointer;background-color: rgba(255,255,255, 0);">
		<table style="width: 100%" class="menu-customer">
			<tr>
				<td><i class="fas fa-user-circle" style="color: orange;font-size: 40px"></i> </td>
				<td width="20"></td>
				<td><b><i class="text-success"><?php echo e(Auth::guard('account_customer')->user()->username); ?></i></b>
					<p class="text-muted">
						<small>
						<?php $type = Auth::guard('account_customer')->user()->person->customer->type;  ?>
						<?php switch($type):
						case ('Thường'): ?>
						<span class="btn btn-sm btn-secondary">
							<?php echo e($type); ?> <i class="fas fa-male"></i>
						</span>
							<?php break; ?>
						<?php case ('Thân thiết'): ?>
						<span class="btn btn-sm btn-info">
							<?php echo e($type); ?> <i class="far fa-handshake"></i>
						</span>
							<?php break; ?>
						<?php case ('Vip'): ?>
						<span class="btn btn-sm btn-warning">
							<?php echo e($type); ?> <i class="fas fa-crown"></i>
						</span>
							<?php break; ?>
						<?php default: ?>
						<?php endswitch; ?>
						</small>
					</p>
				</td>
				<td><i class="fas fa-angle-up d-lg-none d-md-none"></i></td>
			</tr>
		</table>
		
	</div>
	<div class="list-group d-none d-md-block menu-customer-block">
		<a href="<?php echo e(url('/customer/profile')); ?>" class="list-group-item list-group-item-action <?php echo e((request()->is('customer/profile'))? 'list-group-item-secondary text-danger' :''); ?>"><i class="fas fa-address-card"></i> Thông tin cá nhân</a>
		<a href="<?php echo e(url('/customer/change-password')); ?>" class="list-group-item list-group-item-action <?php echo e((request()->is('customer/change-password'))? 'list-group-item-secondary text-danger' :''); ?>"><i class="fas fa-key"></i> Đổi mật khẩu</a>
		<a href="<?php echo e(url('/customer/shipping-address/list')); ?>" class="list-group-item list-group-item-action <?php echo e((request()->is('customer/shipping-address*'))? 'list-group-item-secondary text-danger' :''); ?>"><i class="fas fa-map-marker-alt"></i> Địa chỉ giao hàng</a>
		<a href="<?php echo e(url('/customer/order-history/list')); ?>"class="list-group-item list-group-item-action <?php echo e((request()->is('customer/order-history*'))? 'list-group-item-secondary text-danger' :''); ?>"><i class="fas fa-clipboard-list"></i> Lịch sử đặt hàng</a>
	</div>
</div>
<script type="text/javascript">
	$(function(){
		$('.menu-customer').click(function(){
			$('.menu-customer-block').toggleClass('d-none d-md-block');
			$('.menu-customer tr td:last-child i').toggleClass('fa-angle-up').toggleClass('fa-angle-down');
		});
	});
</script><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/customer/menu.blade.php ENDPATH**/ ?>