
<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Product</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Product</li>
            <li class="breadcrumb-item active "><?php echo e((request()->is('admin-page/product/add'))?'Thêm':'Sửa'); ?></li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="card shadow mb-4">
<div class="card-body">
		<form action="" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<!-- danh mục -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Danh mục</b></div>
				<div class="col-sm-9">
				<select name="intCategory_id" class="form-control" required>
					<option disabled value="0">Chọn danh mục</option>
					<?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($item->id); ?>" <?php echo e((isset($product->category)&&$product->category->id==$item->id)?'selected':''); ?>><?php echo e($item->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				</div>
			</div>
			<!-- tên -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Tên</b></div>
				<div class="col-sm-9">
					<input type="text" name="stringName" value="<?php echo e(isset($product->name)?$product->name:''); ?>" placeholder="Nhập tên sản phẩm" class="form-control" required>
				</div>
			</div>
			<!-- thuong hieu -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Thương hiệu</b></div>
				<div class="col-sm-9">
					<input type="text" name="stringBrand" value="<?php echo e(isset($product->brand)?$product->brand:''); ?>" placeholder="Nhập tên thương hiệu" class="form-control" required>
				</div>
			</div>
			<!-- xuất xứ -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Xuất xứ</b></div>
				<div class="col-sm-9">
					<input type="text" name="stringOrigin" value="<?php echo e(isset($product->origin)?$product->origin:''); ?>" placeholder="Nhập xuất xứ" class="form-control" required>
				</div>
			</div>
			<!-- giá  -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Giá</b></div>
				<div class="col-sm-9">
					<input type="number" name="intPrice" value="<?php echo e(isset($product->price)?$product->price:0); ?>" placeholder="Nhập giá" class="form-control" min="0" required step="1000">
				</div>
			</div>
			<!-- giá khuyến mãi -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Giá ưu đãi</b></div>
				<div class="col-sm-9">
					<input type="number" name="intPromotion_price" value="<?php echo e(isset($product->promotion_price)?$product->promotion_price:0); ?>" placeholder="Nhập giá khuyến mãi(nếu có)" class="form-control" min="0" required step="1000">
				</div>
			</div>
			<?php if($errors->has('intPromotion_price')): ?>
				<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('intPromotion_price')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			 	</button>
				</div>
			<?php endif; ?>
			<!-- mô tả -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Mô tả</b></div>
				<div class="col-sm-9">
					<textarea name="stringDescription" id="stringDescription" class="form-control"><?php echo e(isset($product->description)?$product->description:''); ?></textarea>
					
				</div>
			</div>
			<?php if($errors->has('stringDescription')): ?>
				<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('stringDescription')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			 	</button>
				</div>
			<?php endif; ?>
			<!-- trạng thái bán -->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Trạng thái</b></div>
				<div class="col-sm-9">
					<input type="radio" name="intEnabled" value="1" checked>
					<label>Hiện</label><br>
					<input type="radio" name="intEnabled" value="0" <?php echo e((isset($product->enabled)&&$product->enabled==0)?'checked':''); ?>>
					<label>Ẩn</label><br>
				</div>
			</div>
			<!-- số lượng trong kho-->
			<div class="row mb-2">
				<div class="col-sm-3"><b>Số lượng tồn</b></div>
				<div class="col-sm-9">
					<input type="number" name="intQuantity_in_stock" value="<?php echo e(isset($product->quantity_in_stock)?$product->quantity_in_stock:0); ?>" placeholder="Nhập số lượng tồn" class="form-control" min="0" required>
				</div>
			</div>
			<!-- các ảnh -->
			<div class="alert-img alert alert-info text-center mt-1">Tải lên tối đa 4 ảnh 
				</div>
			<div class="row mb-2">
				<div class="col-sm-3"><b>Ảnh sản phẩm<b></div>
				<div class="col-sm-9 input-group">
					
                    <div class="custom-file">
                        <input type="file" name="images[]" class="custom-file-input" id="exampleInputFile"accept="image/png, image/jpeg" multiple <?php echo e((!isset($product->images)) ?'required':''); ?>>
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                    </div>
                    
                    
				</div>
			</div>
			<?php if($errors->has('images')): ?>
				<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('images')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			 	</button>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-sm-3"></div>
				<?php for($i=0;$i<=3;$i++): ?>
				<div class="col-sm-2 mr-1">
					<img class="image<?php echo e($i); ?> card card-img-top" style="display: none;width: 150px;height: 150px;object-fit: cover;">
				</div>	
				<?php endfor; ?>
			</div>	
			<div class="row mt-1">
				<div class="col-sm-3"></div>
				<div class="col-sm-9">
					<input type="submit" name="" value="Thực thi" class="btn btn-success">
				</div>
			</div>
		</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	 /*product*/
        $('.images').change(function(){
            if(this.files.length>4){
                $('.alert-img').removeClass('alert-info').addClass('alert-danger');
                $(this).val('');
            }
            for ( var i = 0; i < this.files.length; i++) {
                $('.image'+i).css('display','block');
                $('.image'+i).attr('src',URL.createObjectURL(event.target.files[i]));
            }
            for( var i = 3;i>=this.files.length;i--){
                $('.image'+i).css('display','none');
            }   
        });
        /*textarea product*/
        CKEDITOR.replace("stringDescription");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/product/add_edit.blade.php ENDPATH**/ ?>