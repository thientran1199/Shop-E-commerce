<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Review</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Review</li>
            <li class="breadcrumb-item active ">List</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="card shadow mb-4">
<div class="card-body">
    <div class="table-responsive">
    	<table class="table table-bordered table-sm" id="dataTable" cellspacing="0" width="100%">
    		<thead>
	    		<tr>
	    			<th>Id</th>
	    			<th>Mã khách hàng</th>
	    			<th>Mã đơn hàng</th>
	    			<th>Sản phẩm</th>
	    			<th>Xếp hạng</th>
	    			<th>Nhận xét</th>
	    			<th>Thời gian đánh giá</th>
	    		</tr>
    		</thead>

    		<tbody>
    			<?php $__currentLoopData = $listReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<tr>
	    			<td><?php echo e($item->id); ?></td>
	    			<td><?php echo e($item->order_item->order->customer->id); ?></td>
	    			<td><?php echo e($item->order_item->order->id); ?></td>
	    			<td>
	    			<div class="row">
	    				<div class="col-4"><img width="60" src="<?php echo e(asset('/images/product/'.$item->order_item->product->images[0]->name)); ?>"></div>
	    				<div class="col-8"><?php echo e($item->order_item->product->name); ?></div>
	    			</div>
	    			</td>
	    			<td><?php echo e($item->rate); ?>/5</td>
	    			<td><?php echo e($item->comment); ?></td>
	    			<td><?php echo e($item->updated_at); ?></td>
	    		</tr>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</tbody>
		</table>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/review/list.blade.php ENDPATH**/ ?>