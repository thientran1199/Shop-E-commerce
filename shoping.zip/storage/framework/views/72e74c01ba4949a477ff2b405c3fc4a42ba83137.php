    <!--Navigation-->
    <header>

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg  navbar-light scrolling-navbar white">
            <div class="container">
                <!-- SideNav slide-out button -->
                
                <a class="navbar-brand font-weight-bold" href="<?php echo e(url('/')); ?>"><strong>SHOP</strong></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4"
                    aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
                    <ul class="navbar-nav ml-auto">

                        <li class="nav-item ">
                            <a class="nav-link dark-grey-text font-weight-bold <?php echo e((request()->is(['cart','order'])) ? 'd-none' : ''); ?>" href="#" data-toggle="modal" data-target="#cart-modal-ex">
                                <span class="badge danger-color"><?php echo e(session()->has('cart') ? session('cart')->getTotalQuantity():''); ?></span>
                                <i class="fas fa-shopping-cart blue-text" aria-hidden="true"></i>
                                <span class="clearfix d-none d-sm-inline-block">Cart</span>
                            </a>
                        </li>

                        <li class="nav-item ml-3">
                            <a class="nav-link dark-grey-text font-weight-bold" href="<?php echo e(url('/contact')); ?>"><i class="fas fa-envelope blue-text"></i> Contact <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item dropdown ml-3">
                            <a class="nav-link dropdown-toggle dark-grey-text font-weight-bold" id="navbarDropdownMenuLink-4" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><i class="fas fa-user blue-text"></i><?php echo e((Auth::guard('account_customer')->check())?Auth::guard('account_customer')->user()->username:'Profile'); ?></a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-cyan" aria-labelledby="navbarDropdownMenuLink-4">

                                <?php if(!(Auth::guard('account_customer')->check())): ?>
                                <a class="dropdown-item waves-effect waves-light" href="<?php echo e(url('/login')); ?>">Login</a>
                                <a class="dropdown-item waves-effect waves-light" href="<?php echo e(url('signup')); ?>">Signup</a>
                                <?php else: ?>
                                <a class="dropdown-item waves-effect waves-light" href="<?php echo e(url('/customer/profile')); ?>"><i class="fas fa-id-card-alt"></i>Profile</a>
                                <a class="dropdown-item waves-effect waves-light" href="<?php echo e(url('/logout')); ?>"><i class="fas fa-sign-out-alt"></i>Logout</a>

						        
                                <?php endif; ?>
                            </div>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
        <!-- /.Navbar -->

    </header>
    <!-- /.Navigation -->
    <!-- Cart Modal -->
    <?php echo $__env->make('frontend.cart.minicart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /.Cart Modal -->
    <script type="text/javascript">
        $(function(){
            $('.button-mini-cart').click(function(){
            $('.mini-cart').slideToggle();
                });
            /*$('.dropdown-toggle').dropdown();*/
            $('.navbar-toggler').click(function(){
                $('.menu_header').slideToggle();
            });
            // $('#key').change(function(){
            // 	var hrefValue = $('#search').attr('href')+'?search='+$(this).val();
            // 	$('#search').attr('href',hrefValue);
            // });
        });

    </script>
<?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/header.blade.php ENDPATH**/ ?>