<?php $__env->startSection('title'); ?>
	<title>Thay đổi mật khẩu</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<!-- menu -->
		<?php echo $__env->make('frontend.customer.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- end menu -->
		<div class="col-md-9">
			<div class="page-header">
			    <h3>Thay đổi mật khẩu</h3>
			    <hr>
			</div>
			<div class="card-body border rounded bg-white">
				<form method="post">
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label for="stringOldPassword" class="col-md-3 text-muted">Mật khẩu cũ <b style="color: red">*</b></label>
						<input class="col-md-5 form-control" id="stringOldPassword" type="password" name="stringOldPassword" placeholder="Nhập mật khẩu cũ" required>
					</div>
					<div class="form-group row">
						<label for="stringOldPassword" class="col-md-3 text-muted">Mật khẩu mới <b style="color: red">*</b></label>
						<input class="col-md-5 form-control" id="stringPassword" type="password" name="stringPassword" placeholder="Nhập mật khẩu mới" required>
					</div>
					<?php if($errors->has('stringPassword')): ?>
								<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('stringPassword')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    <span aria-hidden="true">&times;</span>
							 	</button>
								</div>
							<?php endif; ?>
					<div class="form-group row">
						<label for="stringOldPassword" class="col-md-3 text-muted">Nhập lại mật khẩu <b style="color: red">*</b></label>
						<input class="col-md-5 form-control" id="stringRePassword" type="password" name="stringRePassword" placeholder="Nhập lại mật khẩu mới" required>
					</div>
					<?php if($errors->has('stringRePassword')): ?>
								<div class="alert alert-danger alert-dismissible text-center mt-1"><?php echo e($errors->first('stringRePassword')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    <span aria-hidden="true">&times;</span>
							 	</button>
								</div>
							<?php endif; ?>
					<input type="submit" name="" class="btn btn-success d-flex justify-content-center" value="Thực thi" style="margin-left: 374px; border-radius: 7px;">
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/customer/change_password.blade.php ENDPATH**/ ?>