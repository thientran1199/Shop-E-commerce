
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Order</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Order</li>
            <li class="breadcrumb-item active ">Detail</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="card shadow mb-4">
<div class="card-body">
	<!--  -->	
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Khách hàng</b></h6>
    	<div class="col-md-9">
    		<table class="table table-bordered table-sm table-responsive" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Loại khách</th>
					<th>Tên</th>
					<th>Giới tính</th>
					<th>Địa chỉ</th>
					<th>Ngày sinh</th>
					<th>Điện thoại</th>
					<th>Email</th>
					<th>Tên tài khoản</th>
				</tr>
			</thead>
			<tbody>
				<?php  
					$item = $order->customer;
				?>
				<tr>
					<td><?php echo e($item->type); ?></td>
					<td><?php echo e($item->person->full_name); ?></td>
					<td><?php echo e($item->person->gender); ?></td>
					<td><?php echo e($item->person->address); ?></td>
					<td><?php echo e($item->person->date_of_birth); ?></td>
					<td><?php echo e($item->person->phone); ?></td>
					<td><?php echo e($item->person->email); ?></td>
					<td><?php echo e($item->person->account->username); ?></td>
				</tr>
			</tbody>
		</table>
    	</div>
	</div>
	<div class="row mb-1">
    	<h6 class="col-md-3"><b>Địa chỉ giao hàng</b></h6>
    	<div class="col-md-9 row">
    		<span class="col-6"><?php echo e($order->shipping_address->recipient_name.' - '.$order->shipping_address->recipient_phone); ?></span>
			<span class="col-6"><?php echo e($order->shipping_address->address_detail.', '.$order->shipping_address->wards.', '.$order->shipping_address->district.', '.$order->shipping_address->province); ?>

			</span>
    	</div>
	</div>
	<!--  -->
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Thanh toán</b></h6>
		<div class="col-md-9 row">
			<span class="col-6"><?php echo e($order->payment->method); ?></span>
			<span class="col-6">
				<?php echo e($order->payment->status); ?>

			</span>
		</div>

	</div>
	<!--  -->
	
	<!--  -->
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Ghi chú</b></h6>
		<div class="col-md-9"><?php echo e(($order->note!='')?$order->note:'(trống)'); ?></div>
	</div>
	<!--  -->
	<!--  -->
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Thời gian đặt hàng</b></h6>
		<div class="col-md-9"><?php echo e($order->created_at); ?></div>
	</div>
	<!--  -->
		<!--  -->
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Tổng số sản phẩm</b></h6>
		<div class="col-md-9"><?php echo e($order->total_quantity); ?></div>
	</div>
	<!--  -->
	<!--  -->
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Tổng tiền</b></h6>
		<div class="col-md-9"><?php echo e(number_format($order->grand_total)); ?>đ</div>
	</div>
	<!--  -->
	<!--  -->
	<form method="post">
		<?php echo csrf_field(); ?>
	<div class="row mb-1">
		<h6 class="col-md-3"><b>Trạng thái đơn</b></h6>
		<div class="col-md-9">
			<div class="row">
	    		<div class="col-md-4 col-sm-7">		
	    			<select name="intStatus" class="form-control mb-1">
	    				<option disabled value="0" <?php echo e(($order->status=='Chờ xử lý')?'selected':''); ?>>Chờ xử lý</option>
	    				<option value="1" <?php echo e(($order->status!='Chờ xử lý')?'disabled':''); ?> <?php echo e(($order->status=='Hủy')?'selected':''); ?>>Hủy</option>
	    				<option value="2" <?php echo e(($order->status=='Đang giao')?'selected':''); ?>>Đang giao</option>
	    				<option value="3" <?php echo e(($order->status!='Đang giao')?'disabled':''); ?> <?php echo e(($order->status=='Đã nhận hàng')?'selected':''); ?>>Đã nhận hàng</option>
	    			</select>
			 	</div>
			 	<?php if($order->status!='Hủy' && $order->status!='Đã nhận hàng'): ?>
			   	<div class="col-md-8 col-sm-5 text-center">
			   		<input type="submit" value="Xử lý đơn" class="btn btn-primary" name=""> 	
			    </div>
			    <?php endif; ?>
			</div>
		</div>
	</div>
	</form>
	<!--  -->
	<div class="row">
    	<h6 class="col-md-3"><b>Danh sách sản phẩm</b></h6>
    	<div style="max-height: 300px;overflow-y: scroll;" class="col-md-6">
	    	<table class="table table-hover table-sm table-responsive" style="width: 100%">
				<tbody>
					<?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align: center;"><img src="<?php echo e(asset('images/product/'.$item->product->images[0]->name)); ?>" style="width: 70px"></td>
						<td>
							<a href="<?php echo e(url('/product/detail/'.$item->product->id)); ?>"><?php echo e($item->product->name); ?></a>
							<p><?php echo e(number_format($item->price_sell)); ?>đ x <?php echo e($item->quantity); ?></p>
						</td>
						<td>Thành tiền<p><b><?php echo e(number_format($item->sub_total)); ?>đ</b></p></td>
					</tr>
					<!-- modal review $item->review->id -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>					
			</table>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/order/detail.blade.php ENDPATH**/ ?>