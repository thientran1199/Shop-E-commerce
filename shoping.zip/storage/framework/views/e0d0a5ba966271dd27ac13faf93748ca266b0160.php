<?php $__env->startSection('title'); ?>
	<title>Chi tiết đơn đặt hàng</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<!-- menu -->
		<?php echo $__env->make('frontend.customer.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- end menu -->
		<div class="col-md-9">
			<div class="page-header">
			    <h3>Lịch sử đặt hàng<small> > Chi tiết đơn hàng</small></h3>
			    <hr>
			</div>
		    <div class="card-body border bg-white rounded">

		    	<!--  -->
		    	<div class="row mb-1">
			    	<h6 class="col-md-3 text-muted">Địa chỉ giao hàng</h6>
			    	<div class="col-md-9 row">
			    		<b class="col-6"><?php echo e($order->shipping_address->recipient_name.' - '.$order->shipping_address->recipient_phone); ?></b>
						<span class="col-6"><?php echo e($order->shipping_address->address_detail.', '.$order->shipping_address->wards.', '.$order->shipping_address->district.', '.$order->shipping_address->province); ?>

						</span>
			    	</div>
		    	</div>
		    	<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Thanh toán</h6>
		    		<div class="col-md-9 row">
						<span class="col-6"><?php echo e($order->payment->method); ?></span>
						<span class="col-6">
							<?php echo e($order->payment->status); ?>

						</span>
					</div>
		    	</div>
		    	<!--  -->
		    	<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Ghi chú</h6>
		    		<div class="col-md-9"><?php echo e(($order->note!='')?$order->note:'(trống)'); ?></div>
		    	</div>
		    	<!--  -->
		    	<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Thời gian đặt hàng</h6>
		    		<div class="col-md-9"><?php echo e($order->created_at); ?></div>
		    	</div>
		    	<!--  -->
		    		<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Tổng số sản phẩm</h6>
		    		<div class="col-md-9"><?php echo e($order->total_quantity); ?></div>
		    	</div>
		    	<!--  -->
		    	<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Tổng tiền</h6>
		    		<div class="col-md-9"><?php echo e(number_format($order->grand_total)); ?>đ</div>
		    	</div>
		    	<!--  -->
		    	<!--  -->
		    	<div class="row mb-1">
		    		<h6 class="text-muted col-md-3">Trạng thái đơn</h6>
		    		<div class="col-md-4"><?php echo e($order->status); ?></div>
		    		<?php if($order->status == 'Chờ xử lý'): ?>
		    		<div class="col-md-5"><a href="<?php echo e(url('/customer/order-history/cancel/'.$order->id)); ?>" class="btn btn-sm btn-danger">Hủy đặt hàng</a></div>
		    		<?php endif; ?>
		    	</div>
		    	<!--  -->
		    	<div class="row">
			    	<h6 class="text-muted col-md-3">Danh sách sản phẩm</h6>
			    	<div style="max-height: 300px;overflow-y: scroll;">
				    	<table class="table table-hover table-sm table-responsive col-md-11" style="background-color: white;">
							<tbody>
								<?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td style="text-align: center;"><img src="<?php echo e(asset('images/product/'.$item->product->images[0]->name)); ?>" style="width: 70px"></td>
									<td>
										<a href="<?php echo e(url('/product/detail/'.$item->product->id)); ?>"><?php echo e($item->product->name); ?></a>
										<p><?php echo e(number_format($item->price_sell)); ?>đ x <?php echo e($item->quantity); ?></p>
									</td>
									<td>Thành tiền<p><b><?php echo e(number_format($item->sub_total)); ?>đ</b></p></td>
									<?php if($order->status=='Đã nhận hàng' && $item->review->reviewed == 0): ?>
									<td><span class="btn btn-sm btn-warning" data-toggle="modal" data-target="#review<?php echo e($item->review->id); ?>">Đánh giá</span></td>
									<?php elseif($order->status=='Đã nhận hàng' && $item->review->reviewed == 1): ?>
									<td><span class="btn btn-sm btn-success">Đã đánh giá</span></td>
									<?php endif; ?>
								</tr>
								<!-- modal review $item->review->id -->
								<div class="modal fade" id="review<?php echo e($item->review->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($item->review->id); ?>"
							        aria-hidden="true">
							        <div class="modal-dialog" role="document">
							            <div class="modal-content">
							                <div class="modal-header">
							                    <h5 class="modal-title" id="exampleModalLabel<?php echo e($item->id); ?>">Đánh giá sản phẩm này</h5>
							                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
							                        <span aria-hidden="true">×</span>
							                    </button>
							                </div>
							                <form method="post" action="">
							                	<?php echo csrf_field(); ?>
								                <div class="modal-body">
								                		<div class="form-group row">
								                			<input type="hidden" name="intReviewId" value="<?php echo e($item->review->id); ?>">
								                			<div class="text-muted col-4">Xếp hạng</div>
												            <h2 class="rate-star col-8" onclick="rateNow(<?php echo e($item->review->id); ?>)">
												            	<label>
												            		<input type="radio" name="intRate" class="rate-review" value="1" checked>
																	<span class="fas fa-star star-rating" id="rate1<?php echo e($item->review->id); ?>"></span>
																</label>
																<label>
												            		<input type="radio" name="intRate" class="rate-review" value="2">
																	<span class="fas fa-star" id="rate2<?php echo e($item->review->id); ?>"></span>
																</label>
																<label>
												            		<input type="radio" name="intRate" class="rate-review" value="3">
																	<span class="fas fa-star" id="rate3<?php echo e($item->review->id); ?>"></span>
																</label>
																<label>
												            		<input type="radio" name="intRate" class="rate-review" value="4">
																	<span class="fas fa-star" id="rate4<?php echo e($item->review->id); ?>"></span>
																</label>
																<label>
												            		<input type="radio" name="intRate" class="rate-review" value="5">
																	<span class="fas fa-star" id="rate5<?php echo e($item->review->id); ?>"></span>
																</label>
															</h2>
								                		</div>
								                		<div class="form-group">
								                			<div class="text-muted">Nhận xét</div>
								                			<textarea class="form-control" name="stringComment" style="resize: none;width: 100%"></textarea>
								                		</div>
								                </div>
								                <div class="modal-footer">
								                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Thoát</button>
								                    <button class="btn btn-primary" type="submit">Đánh giá</button>
								                </div>
							                </form>
							            </div>
							        </div>
							    </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>

		    </div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function rateNow(idReview){
		$('.rate-review').click(function(){
			var rateValue = $(this).val();
			for (var i = 1; i <= rateValue; i++) {
				 $('#rate'+i+idReview).addClass('star-rating');
                //  document.getElementById("rate").style.color = "blue";

			}
			for (var i = 5; i > rateValue; i--) {
				$('#rate'+i+idReview).removeClass('star-rating');
			}
		});
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/frontend/customer/order_history/detail.blade.php ENDPATH**/ ?>