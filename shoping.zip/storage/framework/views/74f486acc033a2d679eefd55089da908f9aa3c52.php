
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Customer</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin-page')); ?>">Home</a></li>
            <li class="breadcrumb-item active ">Customer</li>
            <li class="breadcrumb-item active "><?php echo e((request()->is('admin-page/customer/add'))?'Thêm':'Sửa'); ?></li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="card shadow mb-4">
<div class="card-body">
	<legend>Thông tin cá nhân và tài khoản</legend>
	<hr>
		<div class="row mb-3">
			<div class="col-sm-3"><b>Tên tài khoản</b></div>
			<div class="col-sm-9"><input class="form-control" type="text" name="stringUsername" readonly value="<?php echo e((isset($customer))?$customer->person->account->username:''); ?>"></div>
		</div>
		<div class="row mb-3">
			<div class="col-md-3"><b>Họ và tên</b></div>
			<div class="col-md-9"><input readonly class="form-control" id="stringFullName" type="text" name="stringFullName" placeholder="vd: Lung Thị Linh" value="<?php echo e((isset($customer))?$customer->person->full_name:''); ?>"></div>
		</div>
		<div class="row mb-2">
				<div class="col-sm-3"><b>Trạng thái</b></div>
				<div class="col-sm-9">
					<input type="radio" name="intGender" value="1" disabled checked>
					<label>Nam</label><br>
					<input type="radio" name="intGender" value="0" disabled <?php echo e((isset($customer)&&$customer->person->gender=='Nữ')?'checked':''); ?>>
					<label>Nữ</label><br>
				</div>
		</div>
		<div class="row mb-3">
			<div class="col-md-3"><b>Địa chỉ</b></div>
			<div class="col-md-9"><input readonly class="form-control" id="stringAddress" type="text" name="stringAddress" placeholder="vd: Hà Nam" value="<?php echo e((isset($customer))?$customer->person->address:''); ?>"></div>
		</div>
		<div class="row mb-3">
			<div class="col-md-3"><b>Ngày sinh</b></div>
			<div class="col-sm-9"><input readonly class="form-control" id="dateOfBirth" type="date" name="dateOfBirth" min="1920-01-01" max="2010-12-31" value="<?php echo e((isset($customer))?$customer->person->date_of_birth:''); ?>"></div>
		</div>
		<div class="row mb-3">
			<div class="col-md-3"><b>Số điện thoại</b></div>
			<div class="col-md-9"><input readonly class="form-control" pattern="[0-9]{10}" id="stringPhone" type="tel" name="stringPhone" placeholder="vd: 0843330889" required value="<?php echo e((isset($customer))?$customer->person->phone:''); ?>"></div>
		</div>
		<div class="row mb-3">
			<div class="col-md-3"><b>Email</b></div>
			<div class="col-md-9"><input readonly class="form-control" id="stringEmail" type="email" name="stringEmail" placeholder="vd: lunglinh@mail.com" value="<?php echo e((isset($customer))?$customer->person->email:''); ?>"></div>
		</div>
	<form method="post">
		<?php echo csrf_field(); ?>
		<div class="row mb-3">
			<div class="col-sm-3"><b>Loại khách hàng</b></div>
			<div class="col-sm-9">
				<div class="row">
		    		<div class="col-md-4 col-sm-7">		
		    			<select name="intType" class="form-control mb-1">
		    				<option value="0" <?php echo e(($customer->type=='Thường')?'selected':''); ?>>Thường</option>
		    				<option value="1" <?php echo e(($customer->type=='Thân thiết')?'selected':''); ?>>Thân thiết</option>
		    				<option value="2" <?php echo e(($customer->type=='Vip')?'selected':''); ?>>Vip</option>
		    			</select>
				 	</div>
				   	<div class="col-md-8 col-sm-5 text-center">
				   		<input type="submit" value="Cập nhật loại khách hàng" class="btn btn-primary" name=""> 	
				    </div>
				</div>
			</div>
		</div>
	</form>
	<legend>Danh sách địa chỉ giao hàng</legend>
	<hr>
	<div class="table-responsive">
    	<table class="table table-bordered table-sm" id="dataTable" cellspacing="0" width="100%">
    		<thead>
    			<tr>
    				<th>Id</th>
    				<th>Tên người nhận</th>
    				<th>Điện thoại người nhận</th>
    				<th>Tỉnh/thành phố</th>
    				<th>Quận/huyện</th>
    				<th>Xã/phường</th>
    				<th>Địa chỉ chi tiết</th>
    			</tr>
    		</thead>
    		<tbody>
    			<?php $__currentLoopData = $customer->customer_shipping_addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<tr>
    				<td><?php echo e($item->id); ?></td>
    				<td><?php echo e($item->recipient_name); ?></td>
    				<td><?php echo e($item->recipient_phone); ?></td>
    				<td><?php echo e($item->province); ?></td>
    				<td><?php echo e($item->district); ?></td>
    				<td><?php echo e($item->wards); ?></td>
    				<td><?php echo e($item->address_detail); ?></td>
    			</tr>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</tbody>
    	</table>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thien\Documents\workspace\Projects\shoping\resources\views/backend/customer/detail.blade.php ENDPATH**/ ?>